RESET = u'\33[0m'  # u = Python 2.7.10 Compatibility
BOLD = u'\33[1m'
ITALIC = u'\33[3m'
URL = u'\33[4m'
REVERSE = u'\33[7m'
BLINK = u'\33[5m'  # test terminals' support
BLINK2 = u'\33[6m'  # test terminals' support
