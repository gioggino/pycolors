BLACK = u'\33[30m'

# Default dark fore colors
RED = u'\33[31m'  # 16 colors for major compatibility
GREEN = u'\33[32m'
YELLOW = u'\33[33m'
BLUE = u'\33[34m'
MAGENTA = u'\33[35m'
CYAN = u'\33[36m'
WHITE = u'\33[37m'

GREY = u'\33[90m'

# Light fore colors
LRED = u'\33[91m'
LGREEN = u'\33[92m'
LYELLOW = u'\33[93m'
LBLUE = u'\33[94m'
LMAGENTA = u'\33[95m'
LCYAN = u'\33[96m'
LWHITE = u'\33[97m'
