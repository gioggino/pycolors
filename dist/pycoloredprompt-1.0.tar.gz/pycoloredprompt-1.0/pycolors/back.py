BLACK = u'\33[40m'

# Default dark background colors
RED = u'\33[41m'
GREEN = u'\33[42m'
YELLOW = u'\33[43m'
BLUE = u'\33[44m'
MAGENTA = u'\33[45m'
CYAN = u'\33[46m'
WHITE = u'\33[47m'

GREY = u'\33[100m'

# Light background colors
LRED = u'\33[101m'
LGREEN = u'\33[102m'
LYELLOW = u'\33[103m'
LBLUE = u'\33[104m'
LMAGENTA = u'\33[105m'
LCYAN = u'\33[106m'
LWHITE = u'\33[107m'
