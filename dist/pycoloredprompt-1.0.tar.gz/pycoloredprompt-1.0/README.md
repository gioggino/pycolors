# pycolors

Simple and lightweight cross-platform Python 16 colors terminal text package

pip install pycolors
